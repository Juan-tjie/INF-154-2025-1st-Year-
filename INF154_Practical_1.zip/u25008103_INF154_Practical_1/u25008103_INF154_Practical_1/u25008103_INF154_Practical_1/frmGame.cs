﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace u25008103_INF154_Practical_1
{
    public partial class frmGame : Form
    {
        public frmGame()
        {
            InitializeComponent();
        }

        private void frmGame_Activated(object sender, EventArgs e)    //Starting conditions
        {
            btnClose.Enabled = false;
            btnGoal2.Enabled = false;
            btnReset.Enabled = false;
                            
        }

        private void btnGoal2_Click(object sender, EventArgs e)
        {
            //buttons
            btnGoal2.Enabled = false;
            btnGoal1.Enabled = false;
            btnReset.Enabled = true;
            btnClose.Enabled = true;

            //Ball
            pnlBall.Top = 110;
            pnlBall.Left = 66;
            pnlPlay1.Top = 234;
            pnlPlay2.Top = 50;


            //Words
            lblP1Chant.Text = "Don't give up!";
            lblP1Chant2.Text = "Come on man!";
            lblP2Chant.Text = "Way to go player 2!";
            lblP2Chant2.Text = "Well done!!!";

            //Score
            lblScore.Text = "Current Score: 1 - 1 (10:59)";
            this.BackColor = Color.Purple;
        }

        private void btnGoal1_Click(object sender, EventArgs e)
        {
            //buttons
            btnGoal2.Enabled = true;
            btnGoal1.Enabled = false;

            //Ball
            pnlBall.Top = 324;
            pnlBall.Left = 664;
            pnlPlay1.Top = 164;
            pnlPlay2.Top = 74;


            //Words
            lblP1Chant.Text = "SCORE!";
            lblP1Chant2.Text = "Whoohoo!";
            lblP2Chant.Text = "Don't worry, you got this!";
            lblP2Chant2.Text = "Let's Go player 2!";

            //Score
            lblScore.Text = "Current Score: 1 - 0 (5:32)";
            this.BackColor = Color.PaleGreen;

           

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thanks for playing!","Form Closing",MessageBoxButtons.OK);
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //Ball
            pnlBall.Top = 210;
            pnlBall.Left = 372;

            //Panels
            pnlPlay1.Top = 110;
            pnlPlay2.Top = 110;

            this.BackColor = Color.Gray;

            //Words
            lblP1Chant.Text = "Shoot now!";
            lblP1Chant2.Text = "Please score!";
            lblP2Chant.Text = "Defense!";
            lblP2Chant2.Text = "Defense!";
            lblScore.Text = "Current Score:";

            //buttons
            btnGoal2.Enabled = false;
            btnReset.Enabled = false;
            btnClose.Enabled = true;
            
        }
    }
}
