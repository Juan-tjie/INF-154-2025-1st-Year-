﻿namespace u25008103_INF154_Prac6_c
{
    partial class frmGrades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstData = new System.Windows.Forms.ListBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.grpSort = new System.Windows.Forms.GroupBox();
            this.rdoAverage = new System.Windows.Forms.RadioButton();
            this.rdoPorF = new System.Windows.Forms.RadioButton();
            this.rdoSortAcend = new System.Windows.Forms.RadioButton();
            this.rdoSortDecending = new System.Windows.Forms.RadioButton();
            this.grpSort.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstData
            // 
            this.lstData.FormattingEnabled = true;
            this.lstData.Location = new System.Drawing.Point(97, 103);
            this.lstData.Name = "lstData";
            this.lstData.Size = new System.Drawing.Size(248, 277);
            this.lstData.TabIndex = 0;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(97, 65);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(248, 23);
            this.btnGenerate.TabIndex = 1;
            this.btnGenerate.Text = "Generate Grades";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(400, 245);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(248, 23);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // grpSort
            // 
            this.grpSort.Controls.Add(this.rdoSortDecending);
            this.grpSort.Controls.Add(this.rdoSortAcend);
            this.grpSort.Controls.Add(this.rdoPorF);
            this.grpSort.Controls.Add(this.rdoAverage);
            this.grpSort.Location = new System.Drawing.Point(400, 65);
            this.grpSort.Name = "grpSort";
            this.grpSort.Size = new System.Drawing.Size(248, 174);
            this.grpSort.TabIndex = 3;
            this.grpSort.TabStop = false;
            this.grpSort.Text = "Options:";
            // 
            // rdoAverage
            // 
            this.rdoAverage.AutoSize = true;
            this.rdoAverage.Location = new System.Drawing.Point(16, 20);
            this.rdoAverage.Name = "rdoAverage";
            this.rdoAverage.Size = new System.Drawing.Size(97, 17);
            this.rdoAverage.TabIndex = 0;
            this.rdoAverage.TabStop = true;
            this.rdoAverage.Text = "Average Grade";
            this.rdoAverage.UseVisualStyleBackColor = true;
            // 
            // rdoPorF
            // 
            this.rdoPorF.AutoSize = true;
            this.rdoPorF.Location = new System.Drawing.Point(16, 57);
            this.rdoPorF.Name = "rdoPorF";
            this.rdoPorF.Size = new System.Drawing.Size(132, 17);
            this.rdoPorF.TabIndex = 1;
            this.rdoPorF.TabStop = true;
            this.rdoPorF.Text = "Pass/Fail Grade Count";
            this.rdoPorF.UseVisualStyleBackColor = true;
            // 
            // rdoSortAcend
            // 
            this.rdoSortAcend.AutoSize = true;
            this.rdoSortAcend.Location = new System.Drawing.Point(16, 95);
            this.rdoSortAcend.Name = "rdoSortAcend";
            this.rdoSortAcend.Size = new System.Drawing.Size(135, 17);
            this.rdoSortAcend.TabIndex = 2;
            this.rdoSortAcend.TabStop = true;
            this.rdoSortAcend.Text = "Sort Grades (Acending)";
            this.rdoSortAcend.UseVisualStyleBackColor = true;
            // 
            // rdoSortDecending
            // 
            this.rdoSortDecending.AutoSize = true;
            this.rdoSortDecending.Location = new System.Drawing.Point(16, 135);
            this.rdoSortDecending.Name = "rdoSortDecending";
            this.rdoSortDecending.Size = new System.Drawing.Size(142, 17);
            this.rdoSortDecending.TabIndex = 3;
            this.rdoSortDecending.TabStop = true;
            this.rdoSortDecending.Text = "Sort Grades (Decending)";
            this.rdoSortDecending.UseVisualStyleBackColor = true;
            // 
            // frmGrades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(717, 450);
            this.Controls.Add(this.grpSort);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.lstData);
            this.Name = "frmGrades";
            this.Text = "Practical 6c";
            this.grpSort.ResumeLayout(false);
            this.grpSort.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstData;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.GroupBox grpSort;
        private System.Windows.Forms.RadioButton rdoSortDecending;
        private System.Windows.Forms.RadioButton rdoSortAcend;
        private System.Windows.Forms.RadioButton rdoPorF;
        private System.Windows.Forms.RadioButton rdoAverage;
    }
}

