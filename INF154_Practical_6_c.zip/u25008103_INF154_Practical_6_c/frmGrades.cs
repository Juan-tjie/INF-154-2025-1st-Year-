﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace u25008103_INF154_Prac6_c
{
    public partial class frmGrades : Form
    {
        public frmGrades()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            lstData.Items.Clear();

            Random num = new Random();
            int Count = 0;

            while (Count < 10)
            {
                double Grades = num.NextDouble();
                Grades = Math.Round(Grades * 100, 1);

                lstData.Items.Add(Grades);
                Count++;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int index = 0;
            if (rdoAverage.Checked)
            {
                double Sum = 0;
                while (index < 10)
                {
                    
                    Sum += Convert.ToDouble(lstData.Items[index]);
                    index++;
                }
                double Average = Sum / 10;

                MessageBox.Show("The average grade is: " + Average.ToString("0.0"));

            }
            else if (rdoPorF.Checked)
            {
                int PassCount = 0;
                int failCount = 0;

                while (index < 10)
                {
                    
                    if (Convert.ToDouble(lstData.Items[index]) >= 50)
                    {
                        PassCount++;
                    }
                    else
                    {
                        failCount++;
                    }
                    index++;
                }

                MessageBox.Show($"Passed: {PassCount} \nFailed: {failCount}");

            }
            else if (rdoSortAcend.Checked)
            {
              
                for (int i = 0; i<lstData.Items.Count - 1; i++)
                {
                    for (int j = i + 1; j < lstData.Items.Count; j++)
                    {
                        double first = Convert.ToDouble(lstData.Items[i]);
                        double second = Convert.ToDouble(lstData.Items[j]);
                        if (first > second)
                        {
                            // Swap
                            lstData.Items[i] = second;
                            lstData.Items[j] = first;
                        }
                    }
                }
            }
            else if (rdoSortDecending.Checked)
            {
                for (int i = 0; i < lstData.Items.Count - 1; i++)
                {
                    for (int j = i + 1; j < lstData.Items.Count; j++)
                    {
                        double first = Convert.ToDouble(lstData.Items[i]);
                        double second = Convert.ToDouble(lstData.Items[j]);
                        if (first < second)
                        {
                            // Swap
                            lstData.Items[i] = second;
                            lstData.Items[j] = first;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a sorting method.");
            }
        }
    }
}
