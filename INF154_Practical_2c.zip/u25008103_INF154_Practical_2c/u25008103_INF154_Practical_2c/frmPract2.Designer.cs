﻿namespace u25008103_INF154_Practical_2c
{
    partial class frmPract2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbpOne = new System.Windows.Forms.TabPage();
            this.btnToLeft = new System.Windows.Forms.Button();
            this.brnToRight = new System.Windows.Forms.Button();
            this.lbxRight = new System.Windows.Forms.ListBox();
            this.lbxLeft = new System.Windows.Forms.ListBox();
            this.btnADD = new System.Windows.Forms.Button();
            this.txtNew = new System.Windows.Forms.TextBox();
            this.lblHeading = new System.Windows.Forms.Label();
            this.tbpTwo = new System.Windows.Forms.TabPage();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAddVat = new System.Windows.Forms.Button();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtVAT = new System.Windows.Forms.TextBox();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblVat = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tbpOne.SuspendLayout();
            this.tbpTwo.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbpOne);
            this.tabControl1.Controls.Add(this.tbpTwo);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(796, 453);
            this.tabControl1.TabIndex = 0;
            // 
            // tbpOne
            // 
            this.tbpOne.Controls.Add(this.btnToLeft);
            this.tbpOne.Controls.Add(this.brnToRight);
            this.tbpOne.Controls.Add(this.lbxRight);
            this.tbpOne.Controls.Add(this.lbxLeft);
            this.tbpOne.Controls.Add(this.btnADD);
            this.tbpOne.Controls.Add(this.txtNew);
            this.tbpOne.Controls.Add(this.lblHeading);
            this.tbpOne.Location = new System.Drawing.Point(4, 22);
            this.tbpOne.Name = "tbpOne";
            this.tbpOne.Padding = new System.Windows.Forms.Padding(3);
            this.tbpOne.Size = new System.Drawing.Size(788, 427);
            this.tbpOne.TabIndex = 0;
            this.tbpOne.Text = "Part 1";
            this.tbpOne.UseVisualStyleBackColor = true;
            // 
            // btnToLeft
            // 
            this.btnToLeft.Location = new System.Drawing.Point(302, 219);
            this.btnToLeft.Name = "btnToLeft";
            this.btnToLeft.Size = new System.Drawing.Size(126, 23);
            this.btnToLeft.TabIndex = 5;
            this.btnToLeft.Text = "<<";
            this.btnToLeft.UseVisualStyleBackColor = true;
            this.btnToLeft.Click += new System.EventHandler(this.btnToLeft_Click);
            // 
            // brnToRight
            // 
            this.brnToRight.Location = new System.Drawing.Point(302, 180);
            this.brnToRight.Name = "brnToRight";
            this.brnToRight.Size = new System.Drawing.Size(126, 23);
            this.brnToRight.TabIndex = 4;
            this.brnToRight.Text = ">>";
            this.brnToRight.UseVisualStyleBackColor = true;
            this.brnToRight.Click += new System.EventHandler(this.brnToRight_Click);
            // 
            // lbxRight
            // 
            this.lbxRight.FormattingEnabled = true;
            this.lbxRight.Location = new System.Drawing.Point(455, 143);
            this.lbxRight.Name = "lbxRight";
            this.lbxRight.Size = new System.Drawing.Size(222, 251);
            this.lbxRight.TabIndex = 3;
            // 
            // lbxLeft
            // 
            this.lbxLeft.FormattingEnabled = true;
            this.lbxLeft.Location = new System.Drawing.Point(54, 143);
            this.lbxLeft.Name = "lbxLeft";
            this.lbxLeft.Size = new System.Drawing.Size(222, 251);
            this.lbxLeft.TabIndex = 1;
            // 
            // btnADD
            // 
            this.btnADD.Location = new System.Drawing.Point(54, 83);
            this.btnADD.Name = "btnADD";
            this.btnADD.Size = new System.Drawing.Size(139, 23);
            this.btnADD.TabIndex = 2;
            this.btnADD.Text = "ADD";
            this.btnADD.UseVisualStyleBackColor = true;
            this.btnADD.Click += new System.EventHandler(this.btnADD_Click);
            // 
            // txtNew
            // 
            this.txtNew.Location = new System.Drawing.Point(54, 57);
            this.txtNew.Name = "txtNew";
            this.txtNew.Size = new System.Drawing.Size(139, 20);
            this.txtNew.TabIndex = 1;
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Location = new System.Drawing.Point(51, 31);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(142, 13);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Caputure a new word below:";
            // 
            // tbpTwo
            // 
            this.tbpTwo.Controls.Add(this.btnRemove);
            this.tbpTwo.Controls.Add(this.btnAddVat);
            this.tbpTwo.Controls.Add(this.txtAmount);
            this.tbpTwo.Controls.Add(this.txtVAT);
            this.tbpTwo.Controls.Add(this.lblAmount);
            this.tbpTwo.Controls.Add(this.lblVat);
            this.tbpTwo.Location = new System.Drawing.Point(4, 22);
            this.tbpTwo.Name = "tbpTwo";
            this.tbpTwo.Padding = new System.Windows.Forms.Padding(3);
            this.tbpTwo.Size = new System.Drawing.Size(788, 427);
            this.tbpTwo.TabIndex = 1;
            this.tbpTwo.Text = "Part 2";
            this.tbpTwo.UseVisualStyleBackColor = true;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(340, 220);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(131, 43);
            this.btnRemove.TabIndex = 5;
            this.btnRemove.Text = "Remove Vat";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAddVat
            // 
            this.btnAddVat.Location = new System.Drawing.Point(340, 171);
            this.btnAddVat.Name = "btnAddVat";
            this.btnAddVat.Size = new System.Drawing.Size(131, 43);
            this.btnAddVat.TabIndex = 4;
            this.btnAddVat.Text = "Add Vat";
            this.btnAddVat.UseVisualStyleBackColor = true;
            this.btnAddVat.Click += new System.EventHandler(this.btnAddVat_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(340, 134);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(131, 20);
            this.txtAmount.TabIndex = 3;
            // 
            // txtVAT
            // 
            this.txtVAT.Location = new System.Drawing.Point(340, 78);
            this.txtVAT.Name = "txtVAT";
            this.txtVAT.Size = new System.Drawing.Size(131, 20);
            this.txtVAT.TabIndex = 2;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(337, 118);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(57, 13);
            this.lblAmount.TabIndex = 1;
            this.lblAmount.Text = "AMOUNT:";
            // 
            // lblVat
            // 
            this.lblVat.AutoSize = true;
            this.lblVat.Location = new System.Drawing.Point(337, 62);
            this.lblVat.Name = "lblVat";
            this.lblVat.Size = new System.Drawing.Size(64, 13);
            this.lblVat.TabIndex = 0;
            this.lblVat.Text = "VAT e.g. 14";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tbpOne.ResumeLayout(false);
            this.tbpOne.PerformLayout();
            this.tbpTwo.ResumeLayout(false);
            this.tbpTwo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbpTwo;
        private System.Windows.Forms.TabPage tbpOne;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.TextBox txtNew;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.Button btnToLeft;
        private System.Windows.Forms.Button brnToRight;
        private System.Windows.Forms.ListBox lbxRight;
        private System.Windows.Forms.ListBox lbxLeft;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblVat;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtVAT;
        private System.Windows.Forms.Button btnAddVat;
        private System.Windows.Forms.Button btnRemove;
    }
}

